/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doanspammail;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import jdk.nashorn.internal.runtime.regexp.joni.Regex;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.MatchResult;
import java.util.regex.PatternSyntaxException;

/**
 *
 * @author Tra Tran
 */
public class PhanTich {

    //Đọc file txt
    public static String ReadFile(String FileName) throws FileNotFoundException {
        String str = new String();
        FileInputStream fis = new FileInputStream(FileName);
        Scanner scanner = new Scanner(fis);
        while (scanner.hasNextLine()) {
            str = str + "\r\n" + scanner.nextLine();
        }
        scanner.close();
        return str;
    }

    public static boolean isNumeric(String s) {
        return java.util.regex.Pattern.matches("\\d+", s);
    }

    //Tách từ trong văn bản
    public static ArrayList<String> SplitText(String text) {
        ArrayList<String> l = new ArrayList<String>();
        text = text.replaceAll("\r", "").replaceAll("\n", "");

        String[] array = text.trim().split("\\W+");
        //String[] array = text.trim().split("\\d+");

        for (int i = 0; i < array.length; i++) {
            if (array[i] != null) {
                char[] sc = array[i].toCharArray();
                String temp = "";

                //Chuẩn hóa về chữ thường
                if (array[i].length() == 0) {

                } else {
                    for (int j = 0; j < array[i].length(); j++) {
                        int ascii = sc[j];

                        if (ascii >= 65 && ascii <= 90) {
                            temp += (char) (ascii += 32);
                        } else {
                            temp += (char) ascii;
                        }
                    }
                    if (isNumeric(temp) == false) {
                        l.add(temp);
                    }
                }
            }
            //array[i].toUpperCase();
            //l.add(array[i]);
        }
        return l;
    }
    //Xóa các từ trùng lặp trong listWord

    public static ArrayList<String> RemoveDuplicate(ArrayList<String> listWord) {
        //ArrayList<String> l = new ArrayList<String>();
        //List<String> al = new ArrayList<>();

        Set<String> hs = new HashSet<>();
        hs.addAll(listWord);
        listWord.clear();
        listWord.addAll(hs);

        return listWord;
    }

    public static double probabilityOfHam(ArrayList<String> listWordHam, ArrayList<String> listWordFull, String word) {

        double k = 0;
        for (int i = 0; i < listWordHam.size(); i++) {
            if (listWordHam.get(i).contains(word)) // moi lan x xuat hien trong 1 thu rac thi k++
            {
                k++;
            }
        }
        return (k + 1) / (listWordHam.size() + listWordFull.size());
    }

    public static double probabilityOfSpam(ArrayList<String> listWordSpam, ArrayList<String> listWordFull, String word) {

        double k = 0;
        for (int i = 0; i < listWordSpam.size(); i++) {
            if (listWordSpam.get(i).contains(word)) // moi lan x xuat hien trong 1 thu rac thi k++
            {
                k++;
            }
        }
        return (k + 1) / (listWordSpam.size() + listWordFull.size());
    }

    public static String check(ArrayList<String> listWordInput, ArrayList<String> listWordFull,
            ArrayList<String> listWordHam, ArrayList<String> listWordSpam, double numFileHam, double numFileSpam) {
        //listWordFull = p.RemoveDuplicate(listWordFull);
        double pHam = ((double) numFileHam / (double) (numFileHam + numFileSpam));
        double pSpam = ((double) numFileSpam / (double) (numFileHam + numFileSpam));
        double h = pHam;
        double s = pSpam;
        for (String item : listWordInput) {
            h = (double) (1000*h * probabilityOfHam(listWordHam, listWordFull, item));
            s = (double) (1000*s * probabilityOfSpam(listWordSpam, listWordFull, item));
        }
        if (h >= s) {
            return "Ham" + "\r\n" + Double.toString(h);
        } else {
            return "Spam" + "\r\n" + Double.toString(s);
        }
    }

    public static double precision(String dir, String ss, ArrayList<String> listWordFull,
            ArrayList<String> listWordHam, ArrayList<String> listWordSpam, double numFileHam, double numFileSpam) {

        ArrayList<String> listWordTemp = new ArrayList<String>();
        File folder = new File(dir);
        File[] listOfFiles = folder.listFiles();
        String s = "";
        double tp = 0;
        double fp = 0;
        if (ss == "Ham") {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    try {
                        listWordTemp = SplitText(s + ReadFile(dir + "\\" + file.getName()));
                        if (check(listWordTemp, listWordFull, listWordHam, listWordSpam, numFileHam, numFileSpam).indexOf("Ham") != -1) {
                            tp++;
                        }
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(SpamMail.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        } else {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    try {
                        listWordTemp = SplitText(s + ReadFile(dir + "\\" + file.getName()));
                        if (check(listWordTemp, listWordFull, listWordHam, listWordSpam, numFileHam, numFileSpam).indexOf("Spam") != -1) {
                            tp++;
                        }
                        //listWord = p.SplitText(text);
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(SpamMail.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
        return tp;
    }

    public static ArrayList<String> stopwordRemoval(ArrayList<String> Stopword, ArrayList<String> Input) {
        ArrayList<String> l = new ArrayList<>();
        for (String item : Input) {
            if (Stopword.contains(item) == true) {
                l.add(item);
            }
        }
        return l;
    }
}
